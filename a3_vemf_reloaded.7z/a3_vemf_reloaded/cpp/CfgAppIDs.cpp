class CfgAppIDs
   {
      Apex = 395180;
      Bundle = 304400;
      Heli = 304380;
      Kart = 288520;
      Marksmen = 332350;
      Zeus = 275700;
   };
