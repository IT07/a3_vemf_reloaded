class CfgPatches
{
	class a3_vemf_reloaded_config
	{
		units[] = {};
		requiredAddons[] = {};
		fileName = "a3_vemf_reloaded_config.pbo";
		author = "IT07";
	};
};
