class CfgFunctions
{
	class a3_vemf_reloaded
	{
		tag = "VEMFr";
		class serverFunctions
		{
			file = "a3_vemf_reloaded\fn";
			class checkSide {};
			class config {};
			class findPos {};
			class giveAmmo {};
			class giveWeaponItems {};
			class hc {};
			class launch { postInit = 1; };
			class loadInv {};
			class mines {};
			class modAppID {};
			class playerNear {};
			class scriptPath {};
			class spawnInvasionAI {};
			class spawnVEMFrAI {};
			class waitForPlayers {};
			class whichMod {};
		};
	};
};
