class CfgPatches
{
	class a3_vemf_reloaded
	{
		units[] = {};
		requiredAddons[] = {};
		fileName = "a3_vemf_reloaded.pbo";
		requiredVersion = 1.60; // VEMFr does not work on older versions due to use of the latest scripting commands
		version = "0751.7"; // Do NOT change
		author = "IT07";
	};
};
